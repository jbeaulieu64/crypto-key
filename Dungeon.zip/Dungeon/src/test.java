public class test {
    public static void main(String[] args){
        System.out.println(new Dungeon(30,30).toString());
    }
}
